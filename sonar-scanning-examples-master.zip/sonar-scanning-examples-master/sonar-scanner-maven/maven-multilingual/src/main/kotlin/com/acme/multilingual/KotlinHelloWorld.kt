package com.acme.multilingual

class KotlinHelloWorld {
    fun sayHello() {
        println("Hello World!")
    }

    fun notCovered() {
        println("This method is not covered by unit tests")
    }
}