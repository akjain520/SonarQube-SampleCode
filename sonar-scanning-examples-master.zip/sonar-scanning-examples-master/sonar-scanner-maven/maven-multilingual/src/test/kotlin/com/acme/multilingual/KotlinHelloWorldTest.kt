package com.acme.multilingual

import org.junit.Test

class KotlinHelloWorldTest {

    @Test
    fun sayHello() {
        KotlinHelloWorld().sayHello()
    }
}